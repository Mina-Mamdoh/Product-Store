﻿

namespace ProductStore.Services.Services.Queries
{
    public class ProductQueries : IProductQueries
    {
        private readonly ProductStoreDbContext _context;
        public ProductQueries(ProductStoreDbContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Product>> GetAll()
        {
            try
            {
                return await _context.Products.ToListAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error occurred while fetching products: {ex.Message}");
                return Enumerable.Empty<Product>();
            }
        }

        public async Task<Product> GetById(int id)
        {
            try
            {
                var product = await _context.Products.SingleOrDefaultAsync(p => p.Id == id);
                if (product == null)
                {
                    throw new Exception("Product not found");
                }
                return product;
            }
            catch (Exception ex)
            {
                
                Console.WriteLine($"Error occurred while fetching product with ID {id}: {ex.Message}");
                return null; 
            }
        }
    }
}
