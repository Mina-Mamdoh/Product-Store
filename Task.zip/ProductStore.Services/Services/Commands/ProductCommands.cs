﻿

namespace ProductStore.Services.Services.Commands
{
    public class ProductCommands : IProductCommands
    {
        private readonly ProductStoreDbContext _context;
        public ProductCommands(ProductStoreDbContext context)
        {
            _context = context;
        }

        public async Task<Product> Add(Product product)
        {
            try
            {
                 _context.Products.Add(product);
                await _context.SaveChangesAsync();
                return product;
            }
            catch (Exception ex)
            {

                Console.WriteLine($"Error occurred while adding product: {ex.Message}");
                return null;
            }
        }

        public async Task<Product> Delete(Product product)
        {
            try
            {
                _context.Products.Remove(product);
                await _context.SaveChangesAsync();
                return product;
            }
            catch (Exception ex)
            {
                
                Console.WriteLine($"Error occurred while deleting product: {ex.Message}");
                return null;
            }
        }

        public async Task<Product> Update(Product product)
        {
            try
            {
                _context.Products.Update(product);
                await _context.SaveChangesAsync();
                return product;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error occurred while updating product: {ex.Message}");
                return null;
            }
        }
    }
}
