﻿

namespace ProductStore.Services.IServices.Queries
{
    public interface IProductQueries
    {
        Task<IEnumerable<Product>> GetAll();
        Task<Product> GetById(int id);
    }
}
