﻿

namespace ProductStore.Services.IServices.Commands
{
    public interface IProductCommands
    {
        Task<Product> Add(Product product);
        Task<Product> Update(Product product);
        Task<Product> Delete(Product product);
    }
}
