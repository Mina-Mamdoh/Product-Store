﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductStore.Domain.Constants.Statics
{
    public static class GlobalStatics
    {
        public static class Shared
        {
            public const string ProductStoreConnection = "ProductStoreConnection";
            public const string JwtSettings = "JwtSettings";
            public const string AccessToken = "access_token";
            public const string RealimeViewData = "/RealimeViewData";
        }
    }
}
