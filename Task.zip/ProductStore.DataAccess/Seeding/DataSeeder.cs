﻿using ProductStore.DataAccess.DbContext;
using ProductStore.Domain.Constants.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductStore.DataAccess.Seeding
{
    public  class DataSeeder
    {
        private  ProductStoreDbContext _Context;
        private  UserManager<ApplicationUser> _userManager;
        public DataSeeder(ProductStoreDbContext Context, UserManager<ApplicationUser> userManager)
        {
            _Context = Context;
            _userManager = userManager;

        }
        public async Task SeedData()
        {
            if(!_Context.Users.Any())
            {
                var obj = new ApplicationUser
                {
                    FirstName = "Mina",
                    LastName = "Mamdoh",
                    Email = "Minamamdoh@gmail.com",
                    UserName = "Mina_Mamdoh",
                    EmailConfirmed = true,
                };
                var result =  await _userManager.CreateAsync(obj, "Aaa@123");
                if (result.Succeeded)
                {
                   await  _userManager.AddToRoleAsync(obj, RolesEnums.Admin.ToString());
                }
            }
        }
    }
}
