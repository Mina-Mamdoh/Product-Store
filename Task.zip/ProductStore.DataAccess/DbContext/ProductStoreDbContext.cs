﻿

namespace ProductStore.DataAccess.DbContext
{
    public class ProductStoreDbContext : IdentityDbContext<ApplicationUser>
    {
       

        #region Constructor
        public ProductStoreDbContext(DbContextOptions<ProductStoreDbContext> options) : base(options) { }

        #endregion

        #region Data Sets
        public DbSet<Product> Products { get; set; }
        #endregion

      
    }
}
