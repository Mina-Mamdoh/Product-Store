﻿

namespace ProductStore.API.Profiles
{
    public class ProductProfile : Profile
    {
        public ProductProfile()
        {
            CreateMap<Product,ProductDto>()
                .ReverseMap();

            CreateMap<Product,CreateProductDto>()
                .ReverseMap();
        }
    }
}
