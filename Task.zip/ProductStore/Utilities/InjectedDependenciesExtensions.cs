﻿

namespace ProductStore.API.Utilities
{
    public static class InjectedDependenciesExtensions
    {
        public static IServiceCollection AddDependencies(this IServiceCollection services)
        {
            services.AddScoped<IProductCommands, ProductCommands>();
            services.AddScoped<IProductQueries, ProductQueries>();
            services.AddScoped<IAuthService, AuthService>();
            return services;
        }
    }
}
