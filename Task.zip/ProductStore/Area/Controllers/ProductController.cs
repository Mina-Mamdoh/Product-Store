﻿

namespace ProductStore.API.Area.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductCommands _commands;
        private readonly IProductQueries _queries;
        private readonly IMapper _mapper;

        public ProductController(IProductCommands commands , IProductQueries queries , IMapper mapper)
        {
            _commands = commands;
            _queries = queries;
            _mapper = mapper;
        }
        [HttpGet("[action]")]
        public async Task<IActionResult> GetAllAsync()
        {
            var products = await _queries.GetAll();
            var data = _mapper.Map<IEnumerable<ProductDto>>(products);
            return Ok(data);
        }
        [HttpGet("[action]")]
        public async Task<IActionResult> GetById(int Id)
        {
            var product = await _queries.GetById(Id);
            if(product == null)
            {
                return NotFound();
            }
            var data = _mapper.Map<ProductDto>(product);
            return Ok(data);
        }
        [HttpPost]
        public async Task<IActionResult> CreateAsync([FromForm] CreateProductDto dto)
        {
            var product = _mapper.Map<Product>(dto);
            await _commands.Add(product);
            return Ok(product);
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAsync(int id, [FromBody] UpdateProductDto dto)
        {
            var product = await _queries.GetById(id);

            if(product == null)
                return NotFound($"No product was found with ID {id}");
            else if(dto.Price < 0 && dto.Stock < 0)
            {
                return BadRequest("You mush enter positive value");
            }
            product.Name = dto.Name;
            product.Price = dto.Price;
            product.Stock = dto.Stock;
            product.Description = dto.Description;
            await _commands.Update(product);
            return Ok(product);
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAsync(int id)
        {
            var product = await _queries.GetById(id);

            if (product == null)
                return NotFound($"No Product was found with ID {id}");
            await _commands.Delete(product);
            return Ok(product);
        }

    }
}
